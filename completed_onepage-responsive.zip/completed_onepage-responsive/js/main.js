window.addEventListener('scroll', function (e) {
        var nav = document.getElementById('navbar');
        var navheight = document.getElementById('row2');
        // var navinner = document.getElementById('sub-inner');
        var navinner = document.getElementById('nav-inner');
        var navinner2 = document.getElementById('nav-inner2');
        var navinner3 = document.getElementById('nav-inner3');
        var navinner4 = document.getElementById('nav-inner4');
        var navinner5 = document.getElementById('nav-inner5');
        var navinner6 = document.getElementById('nav-inner6');
        var navinner7 = document.getElementById('nav-inner7');
        var navinner8 = document.getElementById('nav-inner8');
        var navinner9 = document.getElementById('nav-inner9');
        var triangleinfo = document.getElementById('triangle');
        var showhide = document.getElementById('show-hide-map');
        var plus1 = document.getElementById('plus');
        var minus1 = document.getElementById('minus');


        triangleinfo.addEventListener("click",toggle);
        // triangleinfo.addEventListener("click",togglehide);ß
var i=1;
        function toggle(e) {
            e.preventDefault();
            console.log("helloooo");

        if(i==1)
            {
                console.log("toggle");
            showhide.style.visibility="visible";
            plus1.style.visibility='hidden';
            minus1.style.visibility='visible';
            showhide.style.transition="0.3s linear";
            i=0;
        }
        else
        {
            console.log("toggle else");
            showhide.style.visibility="hidden";
            showhide.style.transition="0.3s linear";
            plus1.style.visibility='visible';
            minus1.style.visibility='hidden';
            i=1;

        }
        }

        // function togglehide(){
        //      
        // }
           

        if (document.documentElement.scrollTop || document.body.scrollTop > window.innerHeight) {
                nav.classList.add('sticky');
                navheight.style.padding="10px 0px";
                navheight.style.transition="0.3s ease";
                // navinner.style.padding = "43px 0 0 0";
                navinner.classList.add('navinnerstyle');
                navinner2.classList.add('navinnerstyle');
                navinner3.classList.add('navinnerstyle');
                navinner4.classList.add('navinnerstyle');
                navinner5.classList.add('navinnerstyle');
                navinner6.classList.add('navinnerstyle');
                navinner7.classList.add('navinnerstyle');
                navinner8.classList.add('navinnerstyle');
                navinner9.classList.add('navinnerstyle');
            } 
            else if(document.documentElement.scrollTop<window.innerHeight)
            	{
            		navheight.style.padding="30px 0px";
            		navheight.style.transition="0.3s ease";
            		navinner.classList.remove('navinnerstyle');
            		navinner2.classList.remove('navinnerstyle');
            		navinner3.classList.remove('navinnerstyle');
            		navinner4.classList.remove('navinnerstyle');
            		navinner5.classList.remove('navinnerstyle');
            		navinner6.classList.remove('navinnerstyle');
            		navinner7.classList.remove('navinnerstyle');
            		navinner8.classList.remove('navinnerstyle');
            		navinner9.classList.remove('navinnerstyle');

            		// navinner.style.padding-top = "43px";
        		}

            else {
                nav.classList.remove('sticky');
            }
    });

  // ------------ banner animation -----------

// three buttons for background change
        var bgButton1 = document.getElementById('background_change_button-1');
        var bgButton2 = document.getElementById('background_change_button-2');
        var bgButton3 = document.getElementById('background_change_button-3');

        // three content for three bg
        var textcontent1 = document.getElementById('text1');
        var textcontent2 = document.getElementById('text2');
        var textcontent3 = document.getElementById('text3');

        //bg1 
        var logo=document.getElementById('logo');
        var bg1text_1 = document.getElementById('bg1text1');
        var bg1text_2 = document.getElementById('bg1text2');
        var bg1button_1 = document.getElementById('bg1button1');
        var bg1button_2 = document.getElementById('bg1button2');

        // bg22
        var bg2text_1 = document.getElementById('bg2_text_enter1');
        var bg2text_2 = document.getElementById('bg2_text_enter2');
        var bg2text_3 = document.getElementById('bg2_text_enter3');
        var bg2button = document.getElementById('bg2button');

        // bg3
        var bg3text_1 = document.getElementById('bg3_text_enter1');
        var bg3text_2 = document.getElementById('bg3_text_enter2');
        var bg3button = document.getElementById('bg3button');

        // background background_change_animation
        var bgChangeButton1 = document.getElementById('background_change_button-1');
        var bgChangeButton2 = document.getElementById('background_change_button-2');
        var bgChangeButton3 = document.getElementById('background_change_button-3');

// creating animation class

        // for bg1
        var logo_class=logo.className;
        var bg1text_1_class=bg1text_1.className;
        var bg1text_2_class=bg1text_2.className;
        var bg1button_1_class=bg1button_1.className;
        var bg1button_2_class=bg1button_2.className;

        // for bg2
        var bg2text_1_class=bg2text_1.className;
        var bg2text_2_class=bg2text_2.className;
        var bg2text_3_class=bg2text_3.className;
        var bg2button_class=bg2button.className;

        // for bg3
        var bg3text_1_class=bg3text_1.className;
        var bg3text_2_class=bg3text_2.className;
        var bg3button_class=bg3button.className;

// creating event listener

        bgButton1.addEventListener('click',backGround1);
        bgButton2.addEventListener('click',backGround2);
        bgButton3.addEventListener('click',backGround3);

// background function
        // function for bg1 
        function backGround1(){
            document.getElementById('banner').style.backgroundImage = 'url(images/meeting.jpg)';
            logo.style.opacity = 1;
            bg1button_1.style.visibility = "visible";
            bg1button_2.style.visibility = "visible";
            textcontent1.style.opacity = 1;
            textcontent2.style.opacity = 0;
            textcontent3.style.opacity = 0;

            // background_change_button
            bgChangeButton1.style.backgroundColor = '#fff';
            bgChangeButton2.style.backgroundColor = 'transparent';
            bgChangeButton3.style.backgroundColor = 'transparent';

            removebg();
            bg1animation();
            
        }

        // function for bg2 
        function backGround2(){

            document.getElementById('banner').style.backgroundImage = 'url(images/slide-thinking.jpg)';
            logo.style.opacity = 0;
            bg1button_1.style.visibility = "hidden";
            bg1button_2.style.visibility = "hidden";
            textcontent1.style.opacity = 0;
            textcontent2.style.opacity = 1;
            textcontent3.style.opacity = 0;

            // background_change_button
            bgChangeButton1.style.backgroundColor = 'transparent';
            bgChangeButton2.style.backgroundColor = '#fff';
            bgChangeButton3.style.backgroundColor = 'transparent';

            removebg();
            bg2animation();
        }

        // function for bg3 
        function backGround3(){
            document.getElementById('banner').style.backgroundImage = 'url(images/office.jpg)';
            bg1button_1.style.visibility = "hidden";
            bg1button_2.style.visibility = "hidden";
            textcontent1.style.opacity = 0;
            textcontent2.style.opacity = 0;
            textcontent3.style.opacity = 1;

            // background_change_button
            bgChangeButton1.style.backgroundColor = 'transparent';
            bgChangeButton2.style.backgroundColor = 'transparent';
            bgChangeButton3.style.backgroundColor = '#fff';

            removebg();
            bg3animation();
        }

// animation function for slide1
        function bg1animation(){
            setTimeout(function(){
                logo.className=logo_class+" bg1banneranimation";
                logo.style.top=0;
            },500);

            setTimeout(function(){
                bg1text_1.className=bg1text_1_class+" bg1textanimation";
   
            },1000);
            
            setTimeout(function(){
                bg1text_2.className=bg1text_2_class+" bg1textanimation";
   
            },1500);

            setTimeout(function(){
                bg1button_1.className=bg1button_1_class+" bg1button1";
   
            },2500);

            setTimeout(function(){
                bg1button_2.className=bg1button_2_class+" bg1button2";
   
            },2500);

       }

// animation function for slide2
        function bg2animation(){
            

            setTimeout(function(){
                bg2text_1.className=bg2text_1_class+" text_enter1";
                bg2text_1.style.opacity=1;
   
            },500);
            setTimeout(function(){
                bg2text_2.className=bg2text_2_class+" text_enter1";
                // bg2text_2.style.opacity=1;
   
            },1000);
            setTimeout(function(){
                bg2text_3.className=bg2text_3_class+" text_enter1";
                bg2text_3.style.opacity=1;
   
            },1500);
            

            setTimeout(function(){
                bg2button.className=bg2button_class+" text_enter1";
   
            },2000);

       }

       // animation function for slide3
        function bg3animation(){
            

            setTimeout(function(){
                bg3text_1.className=bg3text_1_class+" text_enter2";
                // bg3text_1.style.opacity=1;
   
            },500);

            setTimeout(function(){
                bg3text_2.className=bg3text_2_class+" text_enter2";
                // bg2text_2.style.opacity=1;
   
            },1000);

            setTimeout(function(){
                bg3button.className=bg3button_class+"  button4animation";
                console.log(bg3button);
                // bg3button.style.opacity = 1;
                // bg3button.style.marginTop = 0;
                // bg3button.style.transition='0.5s';
                // newanimation();
   
            },1500);
            
       }
     
// function calling
        // backGround2();
        replay();

        function replay() {
            // body...
              backGround1();
        setTimeout(function(){
                backGround2();
   
            },4000);
         setTimeout(function(){
                backGround3();
   
            },8000);

         setTimeout(replay,11500);
        }
      
        



        
        


// remove all class
        function removebg(){

            // background remove one

             logo.classList.remove("bg1banneranimation");
             bg1text_1.classList.remove("bg1textanimation");
             bg1text_2.classList.remove("bg1textanimation");
             bg1button_1.classList.remove("bg1button1");
             bg1button_2.classList.remove("bg1button2");
              logo.style.top="-270px";

            // background remove two

             bg2text_1.classList.remove("text_enter1");
             bg2text_2.classList.remove("text_enter1");
             bg2text_3.classList.remove("text_enter1");
             bg2button.classList.remove("text_enter1");

            // background remove three
             bg3text_1.classList.remove("text_enter2");
             bg3text_2.classList.remove("text_enter2");
             bg3button.classList.remove("button4animation");

            
        }

       

