**banner slide work is pending
**footer alignment is pending